package com.klu.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String framework;
    private String salary;
    private String address;
    private String joiningdate;
    private String retireddate;

    public Employee() {
        // Default constructor required by JPA
    }

    public Employee(int id, String firstName, String lastName, String email, String phone, String framework,
                    String salary, String address, String joiningdate, String retireddate) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.framework = framework;
        this.salary = salary;
        this.address = address;
        this.joiningdate = joiningdate;
        this.retireddate = retireddate;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId1(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFramework() {
        return framework;
    }

    public void setFramework(String framework) {
        this.framework = framework;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getJoiningdate() {
        return joiningdate;
    }

    public void setJoiningdate(String joiningdate) {
        this.joiningdate = joiningdate;
    }

    public String getRetireddate() {
        return retireddate;
    }

    public void setRetireddate(String retireddate) {
        this.retireddate = retireddate;
    }

    @Override
    public String toString() {
        return "Employee{" +
               "id=" + id +
               ", firstName='" + firstName + '\'' +
               ", lastName='" + lastName + '\'' +
               ", email='" + email + '\'' +
               ", phone='" + phone + '\'' +
               ", framework='" + framework + '\'' +
               ", salary='" + salary + '\'' +
               ", address='" + address + '\'' +
               ", joiningdate='" + joiningdate + '\'' +
               ", retireddate='" + retireddate + '\'' +
               '}';
    }

	public void setId(int int1) {
		// TODO Auto-generated method stub
		
	}
}
