package com.klu.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.klu.entity.Employee;

public class EmployeeRowMapper implements RowMapper<Employee> {

    @Override
    public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
        Employee employee = new Employee();
        employee.setId(rs.getInt("id"));
        employee.setFirstName(rs.getString("firstname"));
        employee.setLastName(rs.getString("lastname"));
        employee.setEmail(rs.getString("email"));
        employee.setPhone(rs.getString("phone"));
        employee.setFramework(rs.getString("framework"));
        employee.setSalary(rs.getString("salary"));
        employee.setAddress(rs.getString("address"));
        employee.setJoiningdate(rs.getString("joiningdate"));
        employee.setRetireddate(rs.getString("retireddate"));
        return employee;
    }
}
